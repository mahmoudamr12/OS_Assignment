﻿namespace OS__assignment
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Enter_matrix_values = new Button();
            maximum_need_grid = new DataGridView();
            label1 = new Label();
            enter_available_resources = new Button();
            ((System.ComponentModel.ISupportInitialize)maximum_need_grid).BeginInit();
            SuspendLayout();
            // 
            // Enter_matrix_values
            // 
            Enter_matrix_values.Location = new Point(1005, 431);
            Enter_matrix_values.Name = "Enter_matrix_values";
            Enter_matrix_values.Size = new Size(258, 29);
            Enter_matrix_values.TabIndex = 0;
            Enter_matrix_values.Text = " Copy Current Data";
            Enter_matrix_values.UseVisualStyleBackColor = true;
            Enter_matrix_values.Click += button1_Click;
            // 
            // maximum_need_grid
            // 
            maximum_need_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            maximum_need_grid.Location = new Point(283, 12);
            maximum_need_grid.Name = "maximum_need_grid";
            maximum_need_grid.RowHeadersWidth = 70;
            maximum_need_grid.RowTemplate.Height = 29;
            maximum_need_grid.Size = new Size(529, 168);
            maximum_need_grid.TabIndex = 1;
            maximum_need_grid.CellContentClick += maximum_need_grid_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 62);
            label1.Name = "label1";
            label1.Size = new Size(165, 20);
            label1.TabIndex = 3;
            label1.Text = "enter maximum values :";
            // 
            // enter_available_resources
            // 
            enter_available_resources.Location = new Point(720, 431);
            enter_available_resources.Name = "enter_available_resources";
            enter_available_resources.Size = new Size(222, 29);
            enter_available_resources.TabIndex = 4;
            enter_available_resources.Text = "enter available resources";
            enter_available_resources.UseVisualStyleBackColor = true;
            enter_available_resources.Click += enter_available_resources_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1582, 1055);
            Controls.Add(enter_available_resources);
            Controls.Add(label1);
            Controls.Add(maximum_need_grid);
            Controls.Add(Enter_matrix_values);
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)maximum_need_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Enter_matrix_values;
        private DataGridView maximum_need_grid;
        private Label label1;
        private Button enter_available_resources;
    }
}