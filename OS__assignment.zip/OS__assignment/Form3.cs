﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS__assignment
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Copy_data_Click(object sender, EventArgs e)
        {
            int[] x;
            x = new int[BankersAlgorithm.numberOfResources];
            for (int i = 0; i < x.Length; i++)
            {
                x[i] = Convert.ToInt32(available_matrix.Rows[0].Cells[i].Value);
            }
            BankersAlgorithm.available_need_initializer(x);
        }

        private void available_matrix_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            int col_no = 1;
            available_matrix.RowCount = BankersAlgorithm.numberOfProcesses;
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                available_matrix.Columns.Add("col" + col_no, "Res" + col_no);
                col_no++;
            }
            available_matrix.Rows[0].HeaderCell.Value = ("Row" + 0);
        }

        private void enter_currently_allocated_resources_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}
