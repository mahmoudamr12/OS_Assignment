using System;

namespace OS__assignment
{
    class BankersAlgorithm
    {
        public const int numberOfProcesses = 3;
        public const int numberOfResources = 4;
        static int[] available; // Available instances of each resource
        public static int[] total_resources; 
        static int[,] maximum; // Maximum demand of each process
        static int[,] allocation; // Resources allocated to each process
        static int[,] need; // Remaining need of each process
        public static int processNumber;
        public static int[] request;
        static bool[] isSafe; // Safety sequence

        static void Main()
        {
            available = new int[numberOfResources];
            maximum = new int[numberOfProcesses, numberOfResources];
            allocation = new int[numberOfProcesses, numberOfResources];
            need = new int[numberOfProcesses, numberOfResources];
            isSafe = new bool[numberOfProcesses];
            request = new int[numberOfResources];
            total_resources = new int[numberOfResources];
            Application.Run(new Form1());
            //CalculateNeed();
            /*// Read the available instances of each resource
            Console.WriteLine("Enter the number of available instances for each resource:");
            for (int i = 0; i < numberOfResources; i++)
            {
                Console.Write("Resource R" + i + ": ");
                available[i] = Convert.ToInt32(Console.ReadLine());
            }*/

            // Read the maximum demand of each process
            /*Console.WriteLine("Enter the maximum demand of each process:");
            for (int i = 0; i < numberOfProcesses; i++)
            {
                Console.WriteLine("For process P" + i + ":");
                for (int j = 0; j < numberOfResources; j++)
                {
                    Console.Write("Resource R" + j + ": ");
                    maximum[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }*/

            // Read the resources allocated to each process
            /*Console.WriteLine("Enter the resources allocated to each process:");
            for (int i = 0; i < numberOfProcesses; i++)
            {
                Console.WriteLine("For process P" + i + ":");
                for (int j = 0; j < numberOfResources; j++)
                {
                    Console.Write("Resource R" + j + ": ");
                    allocation[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }*/

            // Calculate the need matrix
            // Read the process number and resource request
            /*Console.Write("Enter the process number (0-" + (numberOfProcesses - 1) + "): ");
            int processNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the resource request for process P" + processNumber + ":");
            int[] request = new int[numberOfResources];*/
            /*for (int i = 0; i < numberOfResources; i++)
            {
                Console.Write("Resource R" + i + ": ");
                request[i] = Convert.ToInt32(Console.ReadLine());
            }*/

            // Check if the request can be granted
            /*if (IsSafeToGrant(processNumber, request))
            {
                Console.WriteLine("The request can be granted. System is safe.");
            }
            else
            {
                Console.WriteLine("The request cannot be granted. System may not be safe.");
            }

            Console.ReadLine();*/
        }

        public static void CalculateNeed()
        {
            for (int i = 0; i < numberOfProcesses; i++)
            {
                for (int j = 0; j < numberOfResources; j++)
                {
                    need[i, j] = maximum[i, j] - allocation[i, j];
                }
            }
        }
        public static bool IsSafeToGrant(int processNumber, int[] request)
        {
            // Step 1: Check if the request is less than or equal to the available resources
            for (int i = 0; i < numberOfResources; i++)
            {
                if (request[i] > available[i])
                {
                    return false;
                }
            }

            // Step 2: Try to allocate the resources temporarily
            int[] availableTemp = new int[numberOfResources];
            int[,] allocationTemp = new int[numberOfProcesses, numberOfResources];
            int[,] needTemp = new int[numberOfProcesses, numberOfResources];
            Array.Copy(available, availableTemp, numberOfResources);
            Array.Copy(allocation, allocationTemp, numberOfProcesses * numberOfResources);
            Array.Copy(need, needTemp, numberOfProcesses * numberOfResources);

            // Try to allocate the requested resources temporarily
            for (int i = 0; i < numberOfResources; i++)
            {
                availableTemp[i] -= request[i];
                allocationTemp[processNumber, i] += request[i];
                needTemp[processNumber, i] -= request[i];
            }

            // Step 3: Check if the system is in a safe state with the temporary allocation
            bool[] isProcessFinished = new bool[numberOfProcesses];
            int numberOfFinishedProcesses = 0;
            while (numberOfFinishedProcesses < numberOfProcesses)
            {
                bool isSafeStateFound = false;

                for (int i = 0; i < numberOfProcesses; i++)
                {
                    if (!isProcessFinished[i] && IsNeedLessThanOrEqualToWork(i, availableTemp))
                    {
                        for (int j = 0; j < numberOfResources; j++)
                        {
                            availableTemp[j] += allocationTemp[i, j];
                        }

                        isProcessFinished[i] = true;
                        isSafe[numberOfFinishedProcesses] = true;
                        numberOfFinishedProcesses++;

                        isSafeStateFound = true;
                    }
                }

                if (!isSafeStateFound)
                {
                    break; // No safe state found
                }
            }

            return numberOfFinishedProcesses == numberOfProcesses;
        }
        public static void total_resource_initializer(int[] A_resource)
        {
            total_resources= A_resource;
        }
        public static void maximum_need_initializer(int[,]A_max)
        {
            maximum = A_max;
        }
        public static void available_need_initializer(int[]A_available)
        {
            available = A_available;
        }
        public static void currently_allocated_initializer(int[,]A_current)
        {
            allocation = A_current;
        }
        public static void process_request_initalizer(int A_Process,int [] A_request)
        {
            processNumber = A_Process;
            request = A_request;
            int x = 9;
        }
        static bool IsNeedLessThanOrEqualToWork(int process, int[] work)
        {
            for (int i = 0; i < numberOfResources; i++)
            {
                if (need[process, i] > work[i])
                {
                    return false;
                }
            }

            return true;
        }
    }
}
