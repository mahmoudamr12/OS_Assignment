﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS__assignment
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            int col_no = 1;
            process_resource_request.RowCount = BankersAlgorithm.numberOfProcesses;
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                process_resource_request.Columns.Add("col" + col_no, "Col" + col_no);
                col_no++;
            }
            process_resource_request.Rows[0].HeaderCell.Value = ("Row" + 0);
        }

        private void copy_data_Click(object sender, EventArgs e)
        {
            int x = 5;
            int[] temp = new int[BankersAlgorithm.numberOfResources];
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                if (i == 0)
                {
                    x = Convert.ToInt32(process_resource_request.Rows[0].Cells[i].Value);
                }
                else
                {
                    temp[i - 1] = Convert.ToInt32(process_resource_request.Rows[0].Cells[i].Value);
                }

            }
            BankersAlgorithm.process_request_initalizer(x, temp);
        }

        private void check_for_safety_Click(object sender, EventArgs e)
        {
            process_resource_request.Visible = false;
            Label final = new Label();
            final.Font = new Font("Arial", 12, FontStyle.Bold);
            final.Location = new Point(10, 10);
            final.Size = new Size(300, 30);
            BankersAlgorithm.CalculateNeed();
            bool u = BankersAlgorithm.IsSafeToGrant(BankersAlgorithm.processNumber, BankersAlgorithm.request);
            if (u)
            {
                final.Text = "congrautualtions, you're in the safe zone";
            }
            else
            {
                final.Text = "sorry, granting you the resource would be unsafe";
            }
            this.Controls.Add(final);
        }
    }
}
