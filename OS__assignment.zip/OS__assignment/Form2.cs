﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS__assignment
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int col_no = 1;
            maximum_need_grid.RowCount = BankersAlgorithm.numberOfProcesses;
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                maximum_need_grid.Columns.Add("col" + col_no, "Res" + col_no);
                col_no++;
            }
            maximum_need_grid.RowHeadersVisible = true; // Show row headers
            for (int i = 0; i < BankersAlgorithm.numberOfProcesses; i++)
            {
                maximum_need_grid.Rows[i].HeaderCell.Value = ("P" + i);
                //row_no++;
            }
            Controls.Add(maximum_need_grid);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int[,] x;
            x = new int[BankersAlgorithm.numberOfProcesses, BankersAlgorithm.numberOfResources];
            for (int i = 0; i < BankersAlgorithm.numberOfProcesses; i++)
            {
                for (int j = 0; j < BankersAlgorithm.numberOfResources; j++)
                {
                    x[i, j] = Convert.ToInt32(maximum_need_grid.Rows[i].Cells[j].Value);
                }
            }
            BankersAlgorithm.maximum_need_initializer(x);
        }

        private void maximum_need_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void enter_available_resources_Click(object sender, EventArgs e)
        {
            Form3 Form3 = new Form3();
            Form3.Show();
        }
    }
}
