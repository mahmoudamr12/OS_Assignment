﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS__assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void form1_total_resources_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int col_no = 1;
            total_resources_grid.RowCount = BankersAlgorithm.numberOfProcesses;
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                total_resources_grid.Columns.Add("col" + col_no, "Res" + col_no);
                col_no++;
            }
            total_resources_grid.Rows[0].HeaderCell.Value = ("Row" + 0);
        }

        private void Next_Click(object sender, EventArgs e)
        {
            /*Form form2=new Form();
            form2.Show();*/
            /*maximum_need = new DataGridView();
            maximum_need.Visible = true;
            maximum_need.Location = new Point(190, 10);  // Set the position of the DataGridView
            maximum_need.Size = new Size(300, 200);     // Set the size of the DataGridView
            maximum_need.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Adjust column widths
            int col_no = 1;
            int row_no = 1;*/

            /*// Set custom row header values (optional)
            for (int i = 0; i < maximum_need.Rows.Count; i++)
            {
                maximum_need.Rows[i].HeaderCell.Value = $"Row {i + 1}"; // Customize row header value
            }*/
            //Controls.Add(maximum_need);
            /* maximum_need.EditMode = DataGridViewEditMode.EditOnEnter;
             maximum_need.ReadOnly = false;
             int[,] x;
             x = new int[BankersAlgorithm.numberOfProcesses, BankersAlgorithm.numberOfResources];
             for (int i = 0; i < BankersAlgorithm.numberOfProcesses; i++)
             {
                 for (int j = 0; j < BankersAlgorithm.numberOfResources; j++)
                 {
                     x[i, j] = Convert.ToInt32(maximum_need.Rows[i].Cells[j].Value);
                 }
             }
             BankersAlgorithm.maximum_need_initializer(x);*/
            int[] x;
            x = new int[BankersAlgorithm.numberOfResources];
            for (int i = 0; i < x.Length; i++)
            {
                x[i] = Convert.ToInt32(total_resources_grid.Rows[0].Cells[i].Value);
            }
            BankersAlgorithm.total_resource_initializer(x);

        }
        private void enter_matrix_data_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.Show();
        }
    }
}
