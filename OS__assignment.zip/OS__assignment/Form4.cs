﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OS__assignment
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            int col_no = 1;
            currently_allocated_data_grid.RowCount = BankersAlgorithm.numberOfProcesses;
            for (int i = 0; i < BankersAlgorithm.numberOfResources; i++)
            {
                currently_allocated_data_grid.Columns.Add("col" + col_no, "Res" + col_no);
                col_no++;
            }
            currently_allocated_data_grid.RowHeadersVisible = true; // Show row headers
            for (int i = 0; i < BankersAlgorithm.numberOfProcesses; i++)
            {
                currently_allocated_data_grid.Rows[i].HeaderCell.Value = ("P" + i);
                //row_no++;
            }
            Controls.Add(currently_allocated_data_grid);
        }

        private void currently_allocated_data_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void copy_data_Click(object sender, EventArgs e)
        {
            int[,] x;
            x = new int[BankersAlgorithm.numberOfProcesses, BankersAlgorithm.numberOfResources];
            for (int i = 0; i < BankersAlgorithm.numberOfProcesses; i++)
            {
                for (int j = 0; j < BankersAlgorithm.numberOfResources; j++)
                {
                    x[i, j] = Convert.ToInt32(currently_allocated_data_grid.Rows[i].Cells[j].Value);
                }
            }
            BankersAlgorithm.currently_allocated_initializer(x);
        }

        private void process_request_resource_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
        }
    }
}
