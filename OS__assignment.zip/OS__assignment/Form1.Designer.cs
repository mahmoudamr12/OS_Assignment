﻿namespace OS__assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Next = new Button();
            label1 = new Label();
            enter_matrix_data = new Button();
            total_resources_grid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)total_resources_grid).BeginInit();
            SuspendLayout();
            // 
            // Next
            // 
            Next.Location = new Point(685, 409);
            Next.Name = "Next";
            Next.Size = new Size(171, 29);
            Next.TabIndex = 0;
            Next.Text = "Copy current Data";
            Next.UseVisualStyleBackColor = true;
            Next.Click += Next_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 53);
            label1.Name = "label1";
            label1.Size = new Size(270, 20);
            label1.TabIndex = 2;
            label1.Text = "Please enter total number of resources: ";
            // 
            // enter_matrix_data
            // 
            enter_matrix_data.Location = new Point(468, 409);
            enter_matrix_data.Name = "enter_matrix_data";
            enter_matrix_data.Size = new Size(188, 29);
            enter_matrix_data.TabIndex = 3;
            enter_matrix_data.Text = "enter maximum resources";
            enter_matrix_data.UseVisualStyleBackColor = true;
            enter_matrix_data.Click += enter_matrix_data_Click;
            // 
            // total_resources_grid
            // 
            total_resources_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            total_resources_grid.Location = new Point(286, 12);
            total_resources_grid.Name = "total_resources_grid";
            total_resources_grid.RowHeadersWidth = 70;
            total_resources_grid.RowTemplate.Height = 29;
            total_resources_grid.Size = new Size(529, 168);
            total_resources_grid.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(935, 450);
            Controls.Add(total_resources_grid);
            Controls.Add(enter_matrix_data);
            Controls.Add(label1);
            Controls.Add(Next);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)total_resources_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Next;
        private Label label1;
        private Button enter_matrix_data;
        private DataGridView total_resources_grid;
    }
}