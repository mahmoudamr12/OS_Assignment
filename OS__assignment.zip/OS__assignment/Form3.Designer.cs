﻿namespace OS__assignment
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Copy_data = new Button();
            label1 = new Label();
            available_matrix = new DataGridView();
            enter_currently_allocated_resources = new Button();
            ((System.ComponentModel.ISupportInitialize)available_matrix).BeginInit();
            SuspendLayout();
            // 
            // Copy_data
            // 
            Copy_data.Location = new Point(1107, 474);
            Copy_data.Name = "Copy_data";
            Copy_data.Size = new Size(194, 29);
            Copy_data.TabIndex = 0;
            Copy_data.Text = "Copy current data";
            Copy_data.UseVisualStyleBackColor = true;
            Copy_data.Click += Copy_data_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 58);
            label1.Name = "label1";
            label1.Size = new Size(180, 20);
            label1.TabIndex = 1;
            label1.Text = "Enter available resources :";
            // 
            // available_matrix
            // 
            available_matrix.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            available_matrix.Location = new Point(364, 12);
            available_matrix.Name = "available_matrix";
            available_matrix.RowHeadersWidth = 70;
            available_matrix.RowTemplate.Height = 29;
            available_matrix.Size = new Size(695, 105);
            available_matrix.TabIndex = 2;
            available_matrix.CellContentClick += available_matrix_CellContentClick;
            // 
            // enter_currently_allocated_resources
            // 
            enter_currently_allocated_resources.Location = new Point(780, 474);
            enter_currently_allocated_resources.Name = "enter_currently_allocated_resources";
            enter_currently_allocated_resources.Size = new Size(262, 29);
            enter_currently_allocated_resources.TabIndex = 3;
            enter_currently_allocated_resources.Text = "enter currently allocated resources";
            enter_currently_allocated_resources.UseVisualStyleBackColor = true;
            enter_currently_allocated_resources.Click += enter_currently_allocated_resources_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1582, 1055);
            Controls.Add(enter_currently_allocated_resources);
            Controls.Add(available_matrix);
            Controls.Add(label1);
            Controls.Add(Copy_data);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)available_matrix).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Copy_data;
        private Label label1;
        private DataGridView available_matrix;
        private Button enter_currently_allocated_resources;
    }
}