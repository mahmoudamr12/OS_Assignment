﻿namespace OS__assignment
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            copy_data = new Button();
            process_resource_request = new DataGridView();
            label1 = new Label();
            check_for_safety = new Button();
            ((System.ComponentModel.ISupportInitialize)process_resource_request).BeginInit();
            SuspendLayout();
            // 
            // copy_data
            // 
            copy_data.Location = new Point(725, 437);
            copy_data.Name = "copy_data";
            copy_data.Size = new Size(194, 29);
            copy_data.TabIndex = 6;
            copy_data.Text = "Copy current Data";
            copy_data.UseVisualStyleBackColor = true;
            copy_data.Click += copy_data_Click;
            // 
            // process_resource_request
            // 
            process_resource_request.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            process_resource_request.Location = new Point(232, 47);
            process_resource_request.Name = "process_resource_request";
            process_resource_request.RowHeadersWidth = 70;
            process_resource_request.RowTemplate.Height = 29;
            process_resource_request.Size = new Size(529, 168);
            process_resource_request.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1, 62);
            label1.Name = "label1";
            label1.Size = new Size(170, 20);
            label1.TabIndex = 8;
            label1.Text = "Enter resources needed: ";
            // 
            // check_for_safety
            // 
            check_for_safety.Location = new Point(471, 437);
            check_for_safety.Name = "check_for_safety";
            check_for_safety.Size = new Size(183, 29);
            check_for_safety.TabIndex = 9;
            check_for_safety.Text = "check for safety";
            check_for_safety.UseVisualStyleBackColor = true;
            check_for_safety.Click += check_for_safety_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(981, 587);
            Controls.Add(check_for_safety);
            Controls.Add(label1);
            Controls.Add(process_resource_request);
            Controls.Add(copy_data);
            Name = "Form5";
            Text = "Form5";
            Load += Form5_Load;
            ((System.ComponentModel.ISupportInitialize)process_resource_request).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button copy_data;
        private DataGridView process_resource_request;
        private Label label1;
        private Button check_for_safety;
    }
}