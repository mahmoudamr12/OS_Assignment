﻿namespace OS__assignment
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            copy_data = new Button();
            currently_allocated_data_grid = new DataGridView();
            process_request_resource = new Button();
            ((System.ComponentModel.ISupportInitialize)currently_allocated_data_grid).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-1, 91);
            label1.Name = "label1";
            label1.Size = new Size(213, 20);
            label1.TabIndex = 0;
            label1.Text = "Enter Currently Allocated Data:";
            // 
            // copy_data
            // 
            copy_data.Location = new Point(861, 470);
            copy_data.Name = "copy_data";
            copy_data.Size = new Size(174, 29);
            copy_data.TabIndex = 1;
            copy_data.Text = "Copy current Data";
            copy_data.UseVisualStyleBackColor = true;
            copy_data.Click += copy_data_Click;
            // 
            // currently_allocated_data_grid
            // 
            currently_allocated_data_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            currently_allocated_data_grid.Location = new Point(297, 30);
            currently_allocated_data_grid.Name = "currently_allocated_data_grid";
            currently_allocated_data_grid.RowHeadersWidth = 70;
            currently_allocated_data_grid.RowTemplate.Height = 29;
            currently_allocated_data_grid.Size = new Size(529, 168);
            currently_allocated_data_grid.TabIndex = 2;
            currently_allocated_data_grid.CellContentClick += currently_allocated_data_grid_CellContentClick;
            // 
            // process_request_resource
            // 
            process_request_resource.Location = new Point(461, 470);
            process_request_resource.Name = "process_request_resource";
            process_request_resource.Size = new Size(322, 29);
            process_request_resource.TabIndex = 3;
            process_request_resource.Text = "Enter process that requests a resource";
            process_request_resource.UseVisualStyleBackColor = true;
            process_request_resource.Click += process_request_resource_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1087, 588);
            Controls.Add(process_request_resource);
            Controls.Add(currently_allocated_data_grid);
            Controls.Add(copy_data);
            Controls.Add(label1);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)currently_allocated_data_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button copy_data;
        private DataGridView currently_allocated_data_grid;
        private Button process_request_resource;
    }
}